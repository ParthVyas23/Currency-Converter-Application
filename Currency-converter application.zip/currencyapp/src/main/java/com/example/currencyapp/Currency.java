package com.example.currencyapp;

public class Currency {
    private final String name;
    private final double exchangeRate;

    public Currency(String name, double exchangeRate) {
        this.name = name;
        this.exchangeRate = exchangeRate;
    }

    public String getName() {
        return name;
    }

    public double getExchangeRate() {
        return exchangeRate;
    }

    public double convert(double amount, Currency toCurrency) {
        double fromRate = this.getExchangeRate();
        double toRate = toCurrency.getExchangeRate();
        return amount * (fromRate / toRate);
    }
}
