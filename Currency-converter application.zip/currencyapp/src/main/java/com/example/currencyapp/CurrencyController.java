package com.example.currencyapp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CurrencyController {
    @FXML private TextField txtAmount;
    @FXML private TextArea txtResult;
    @FXML private ComboBox<String> cboFrom;
    @FXML private ComboBox<String> cboTo;
    @FXML private MenuItem menuItemExit;
    @FXML private MenuItem menuItemAbout;

    private List<Currency> currencyList;
    @FXML
    public void initialize(){
        currencyList = new ArrayList<>();
        // define currencies
        currencyList.add(new Currency("USD", 1.0));
        currencyList.add(new Currency("EUR", 1.05887));
        currencyList.add(new Currency("GBP", 1.21428));

        // clear items
        cboFrom.getItems().clear();
        cboTo.getItems().clear();

        // populate currency combo boxes
        List<String> currencies = currencyList.stream().map(Currency::getName).toList();
        cboFrom.getItems().addAll(currencies);
        cboTo.getItems().addAll(currencies);

        // add real-time event listeners
        txtAmount.textProperty().addListener((observable, oldValue, newValue) -> convertCurrency());
        cboFrom.setOnAction(event -> convertCurrency());
        cboTo.setOnAction(event -> convertCurrency());

        // about and exit
        menuItemAbout.setOnAction(event ->showAbout());
        menuItemExit.setOnAction(event -> CurrencyApplication.exit());
    }

    protected void showAbout(){
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("about.fxml"));
            Parent root = fxmlLoader.load();

            Stage aboutDialogStage = new Stage();
            aboutDialogStage.initStyle(StageStyle.UTILITY);
            aboutDialogStage.initModality(Modality.WINDOW_MODAL);
            Stage stage = new Stage();
            aboutDialogStage.initOwner(stage);
            Scene scene = new Scene(root);
            aboutDialogStage.setScene(scene);
            aboutDialogStage.setTitle("About Currency Controller");

            aboutDialogStage.setResizable(false);

            aboutDialogStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    protected void convertCurrency() {
        try {

            // check amount
            if (txtAmount.getText().isEmpty()) {
                return;
            }

            // get selected currencies
            String from = cboFrom.getValue();
            String to = cboTo.getValue();

            // user has not selected one of the currencies
            if (from == null || to == null) {
                return;
            }

            // get amount
            double amount = Double.parseDouble(txtAmount.getText());

            Currency fromCurrency = null;
            Currency toCurrency = null;

            // retrieve currencies
            for (Currency currency : currencyList) {
                if (currency.getName().equals(from)) {
                    fromCurrency = currency;
                }

                if (currency.getName().equals(to)) {
                    toCurrency = currency;
                }
            }

            if (amount >= 0 && fromCurrency != null && toCurrency != null) {

                double result = fromCurrency.convert(amount, toCurrency);

                double reverseRate = toCurrency.getExchangeRate() / fromCurrency.getExchangeRate();
                double exchangeRate = fromCurrency.getExchangeRate() / toCurrency.getExchangeRate();

                txtResult.setText(String.format("%.2f %s = %.2f %s", amount, fromCurrency.getName(), result, toCurrency.getName()));
                txtResult.appendText(String.format("\n1 %s = %.2f %s", fromCurrency.getName(), exchangeRate, toCurrency.getName()));
                txtResult.appendText(String.format("\n1 %s = %.2f %s", toCurrency.getName(), reverseRate, fromCurrency.getName()));
            } else {
                showError("Please select From and To Currencies");
            }
        } catch (Exception exception){
            showError(exception.getMessage());
        }
    }

    public void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid User Inputs");
        alert.setContentText(message);
        alert.showAndWait();
    }
}