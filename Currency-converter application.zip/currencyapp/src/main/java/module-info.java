module com.example.currencyapp {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.currencyapp to javafx.fxml;
    exports com.example.currencyapp;
}